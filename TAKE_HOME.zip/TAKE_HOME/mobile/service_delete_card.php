<?php
$mysqli = new mysqli("localhost", "root", "", "_mobile");

/* check connecton state*/
if ($mysqli->connect_errno) 
{
    printf("Database connect error: %s\n", $mysqli->connect_error);
    exit();
}

	$card_id = $_GET["card_id"];
	$sql = "DELETE FROM table_cards WHERE ID = ".$card_id;
	
	if ($mysqli->query($sql) === TRUE) 
	{
		$sql = "DELETE FROM table_analytics WHERE CID = ".$card_id;
		$mysqli->query($sql);
		$resText = "<Rslt>Ok</Rslt>";
	}
	else 
	{
		$resText = "<Rslt>Error</Rslt>";
	}
}
echo $resText;

/* Fermeture de la connexion */
$mysqli->close();
?>
