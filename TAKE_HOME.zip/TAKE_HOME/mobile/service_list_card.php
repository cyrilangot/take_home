<?php
$mysqli = new mysqli("localhost", "root", "", "_mobile");

/* check connecton state*/
if ($mysqli->connect_errno) 
{
    printf("Database connect error: %s\n", $mysqli->connect_error);
    exit();
}

$user_id = $_GET["user_id"];

$req = sprintf("SELECT * FROM table_cards WHERE UID='%s'", $user_id);
$result = $mysqli->query($req);

echo "<cards>\n";

while($row = mysqli_fetch_array($result)) 
{
	$name = $row['NAME'];
	$summary = $row['SUMMARY'];
	$type = $row['TYPE'];
	$id = $row['ID'];
	
	$usedtype = "";
	if ($type == 0)
	{
		$usedtype = "visa";
	}
	else
	{
		$usedtype = "mastercard";
	}
	
	echo "<card id='".$id."' name='".$name."' summary='".$summary."' type='".$usedtype."'>\n";
} 	
		
echo "</Cards>\n";

/* Fermeture de la connexion */
$mysqli->close();
?>
