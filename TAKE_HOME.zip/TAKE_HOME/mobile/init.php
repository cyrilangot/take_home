<!DOCTYPE html>
<html>
<head>
	<title>Mobile</title>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width">
</head>

<body>

<?php
$mysqli = new mysqli("localhost", "root", "", "");

/* check connecton state*/
if ($mysqli->connect_errno) 
{
    printf("Database connect error: %s\n", $mysqli->connect_error);
    exit();
}

$bReady = true;
// Create database
$sql="CREATE DATABASE IF NOT EXISTS _mobile";
if (mysqli_query($mysqli, $sql))
{
	//echo "Database _mobile created successfully<br><br>";
	
	mysqli_select_db($mysqli, "_mobile");

    $sql_user = "CREATE TABLE IF NOT EXISTS table_users (
		ID INT(8) UNSIGNED AUTO_INCREMENT PRIMARY KEY,  
		NAME VARCHAR(30) NOT NULL, 
		MAIL VARCHAR(30) NOT NULL, 
		PWD VARCHAR(30) NOT NULL)";

    $sql_cards = "CREATE TABLE IF NOT EXISTS table_cards (
            ID INT(8) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            UID INT(8) UNSIGNED,
            TYPE INT(8) UNSIGNED,
            NAME VARCHAR(30) NOT NULL,
            SUMMARY VARCHAR(30) NOT NULL)";

    $sql_analytics = "CREATE TABLE IF NOT EXISTS table_analytics (
            ID INT(8) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            CID INT(8) UNSIGNED,
            DATA VARCHAR(100) NOT NULL)";

	if ($mysqli->query($sql_user) === TRUE) 
	{
		//echo "Table table_users created successfully<br>";
	} 
	else 
	{
		$bReady = false;
		echo "Error creating table: " . $mysqli->error;
	}
	if ($mysqli->query($sql_cards) === TRUE) 
	{
		//echo "Table table_cards created successfully<br>";
	} 
	else 
	{
		$bReady = false;
		echo "Error creating table: " . $mysqli->error;
	}

	if ($mysqli->query($sql_analytics) === TRUE) 
	{
		//echo "Table table_analytics created successfully<br>";
	} 
	else 
	{
		$bReady = false;
		echo "Error creating table: " . $mysqli->error;
	}
	
	if ($bReady == true)
	{
		echo "Database ready<br><br>";
		$req = "SELECT * FROM table_users";

		$result = $mysqli->query($req);
	
		$switch = true;

		echo "<b>Users:</b>";
		echo "<hr><table  border='1'>";
		echo "<tr><th width = '100px' align='left'>NAME</th><th width='200px' align='left'>MAIL</th><th>-</th></tr>";

		while($row = mysqli_fetch_array($result)) 
		{
			if ($switch == true)
			{
				$color = "bgcolor='#D0D0D0'";
			}
			else
			{
				$color = "bgcolor='#A0A0A0'";
			}
			$switch = !$switch;
			
			$name = $row['NAME'];
			$mail = $row['MAIL'];
			$id = $row['ID'];
			echo "<tr ".$color."><td>".$name."</td><td>".$mail."</td>";
			echo "<td><form><input type='button' value='V' onclick='window.location.href=\"user.php?user_id=".$id."\"'</form></td>"; 			
			echo "</tr>";
		} 	
				
		echo "</table><hr>";
		
 		echo "<b>Add new user:</b><br>";
		?><form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
  <div>
    <label for="name">Name:</label>
    <input type="text" id="name" name="user_name">
    <label for="mail">E-mail:</label>
    <input type="email" id="mail" name="user_mail">
    <label for="pwd">Pwd:</label>
    <input type="text" id="pwd" name="user_pwd">
	<button type="submit">Add user</button>
	<input type="hidden" id="action" name="action" value="1">
  </div>
</form>	
<?php
		$action = 0;
		if (isset($_GET["action"]))
		{
			$action = $_GET["action"];
		}
		
		$resText =  "";
		
		if ($action != 0)
		{
			$name = $_GET["user_name"];
			$mail = $_GET["user_mail"];
			$pwd = $_GET["user_pwd"];


			if (($name == "") || ($mail == "") || ($pwd == ""))
			{
				$resText = "invalid parameter";
			}
			else
			{
				$reqexists = sprintf("SELECT * FROM table_users WHERE NAME='%s' AND MAIL='%s'", $name, $mail);

				$result = $mysqli->query($reqexists);

				$row_cnt = mysqli_num_rows($result);
				mysqli_free_result($result);
				
				if ($row_cnt > 0)
				{
					$resText = "User exists!!!";
				}
				else
				{
					$sql = "INSERT INTO table_users (NAME, MAIL, PWD) VALUES ('".$name."', '".$mail."', '".$pwd."')";

					if ($mysqli->query($sql) === TRUE) 
					{
						$resText = "User Added";
					}
					else 
					{
						$resText = "Database error";
					}
				}	
				
			}
		}
		echo "<hr>".$resText;
	}
	
}
else
{
	echo "Error creating database: " . mysqli_error($mysqli);
}

/* Fermeture de la connexion */
$mysqli->close();
?>
	</div>
</body>
</html>