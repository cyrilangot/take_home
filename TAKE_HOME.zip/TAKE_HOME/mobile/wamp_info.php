<!DOCTYPE html>
<html>
<head>
	<title>Mobile</title>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width">
</head>

<body>
  <div id="head">
    <div class="innerhead">
	    <h1><abbr title="Windows">W</abbr><abbr title="Apache">A</abbr><abbr title="MySQL">M</abbr><abbr title="PHP">P</abbr></h1>
		   <ul>
		    <li>PHP 5</li>
			   <li>Apache 2.4</li>
			   <li>MySQL 5</li>
		   </ul>
     </div>
	</div>
</body>
</html>