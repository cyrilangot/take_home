<?php
$mysqli = new mysqli("localhost", "root", "", "_mobile");

/* check connecton state*/
if ($mysqli->connect_errno) 
{
	echo "<Rslt>Error</Rslt>";
    exit();
}
else
{
	if (isset($_GET["name"]) && isset($_GET["pwd"]))
	{
		$name = $_GET["name"];
		$pwd = $_GET["pwd"];
		
		$req = "SELECT ID FROM table_users WHERE NAME='".$name."' AND PWD='".$pwd."'";

		$result = $mysqli->query($req);

		$row_cnt = mysqli_num_rows($result);
		if ($row_cnt != 0)
		{
			$row = mysqli_fetch_array($result);
			$id = $row['ID'];			
			echo "<Rslt>".$id."</Rslt>";
		}
		else
		{
			echo "<Rslt>-1</Rslt>";
		}

		mysqli_free_result($result);
		
	}
	else
	{
		echo "<Rslt>Error</Rslt>";
	}
}

/* Fermeture de la connexion */
$mysqli->close();
?>
