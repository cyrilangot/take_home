<!DOCTYPE html>
<html>
<head>
	<title>Mobile</title>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width">
</head>

<body>

<?php
$mysqli = new mysqli("localhost", "root", "", "_mobile");

/* check connecton state*/
if ($mysqli->connect_errno) 
{
    printf("Database connect error: %s\n", $mysqli->connect_error);
    exit();
}

if (isset($_GET["user_id"]))
{
	$user_id = $_GET["user_id"];
}
else
{
	exit();
}

$reqexists = sprintf("SELECT * FROM table_users WHERE ID='%s'", $user_id);
$result = $mysqli->query($reqexists);

$row = mysqli_fetch_array($result);
	
$name = $row['NAME'];
$mail = $row['MAIL'];

echo "<b>Current User:</b><br>";
echo "Name ".$name." Mail ".$mail;

$req = sprintf("SELECT * FROM table_cards WHERE UID='%s'", $user_id);
$result = $mysqli->query($req);

$switch = true;

echo "<b>:</b>";
echo "<hr><table  border='1'>";
echo "<tr><th width = '100px' align='left'>NAME</th><th width='200px' align='left'>SUMMARY</th><th width='50px' align='left'>TYPE</th><th>-</th><th>-</th></tr>";

while($row = mysqli_fetch_array($result)) 
{
	if ($switch == true)
	{
		$color = "bgcolor='#D0D0D0'";
	}
	else
	{
		$color = "bgcolor='#A0A0A0'";
	}
	$switch = !$switch;
	
	$name = $row['NAME'];
	$summary = $row['SUMMARY'];
	$type = $row['TYPE'];
	$id = $row['ID'];
	
	$usedtype = "";
	if ($type == 0)
	{
		$usedtype = "visa";
	}
	else
	{
		$usedtype = "mastercard";
	}
	
	echo "<tr ".$color."><td>".$name."</td><td>".$summary."</td><td>".$usedtype."</td>";
	echo "<td><form><input type='button' value='D' onclick='window.location.href=\"user.php?action=2&user_id=".$user_id."&card_id=".$id."\"'</form></td>"; 			
	echo "<td><form><input type='button' value='V' onclick='window.location.href=\"analytic.php?card_id=".$id."\"'</form></td>"; 			
	echo "</tr>";
} 	
		
echo "</table><hr>";

echo "<b>Add new card:</b><br>";
?>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
  <div>
    <label for="name">Name:</label>
    <input type="text" id="name" name="card_name">
    <label for="mail">Summary:</label>
    <input type="text" id="mail" name="card_summary">

	<input type="radio" id="type1" checked="true"
     name="type" value="visa">
    <label for="type1">Visa</label>

    <input type="radio" id="type2"
     name="type" value="Mastercard">
    <label for="type2">Mastercard</label>
	
	<button type="submit">Add card</button>
	<input type="hidden" id="action" name="action" value="1">
	<input type="hidden" id="user_id" name="user_id" value="<?php echo $user_id?>">
  </div>
</form>	
<?php

$action = 0;

if (isset($_GET["action"]))
{
	$action = $_GET["action"];
}

$resText =  "";

if ($action == 1)
{
	$name = $_GET["card_name"];
	$summary = $_GET["card_summary"];
	$type = $_GET["type"];


	if (($name == "") || ($mail == "") || ($type == ""))
	{
		$resText = "invalid parameter";
	}
	else
	{
		$reqexists = sprintf("SELECT * FROM table_cards WHERE NAME='%s'", $name);

		$result = $mysqli->query($reqexists);

		$row_cnt = mysqli_num_rows($result);
		mysqli_free_result($result);
		
		if ($row_cnt > 0)
		{
			$resText = "Card exists!!!";
		}
		else
		{
			$utype = "0";
			if ($type == "visa")
			{
				$utype = "0";
			}
			else
			{
				$utype = "1";
			}
			$sql = "INSERT INTO table_cards (NAME, SUMMARY, TYPE, UID) VALUES ('".$name."', '".$summary."', ".$utype.", ".$user_id.")";
			//echo $sql;

			if ($mysqli->query($sql) === TRUE) 
			{
				$new_id = $mysqli->insert_id;
				$resText = "Card Added";
				$sql = "INSERT INTO table_analytics (DATA, CID) VALUES ('Default Analytics', ".$new_id.")";
				if ($mysqli->query($sql) === TRUE)
				{
				}
				else
				{
					$resText = "Database error";
				}
			}
			else 
			{
				$resText = "Database error";
			}
		}	
		
	}
}
else if ($action == 2)
{
	$card_id = $_GET["card_id"];
	$sql = "DELETE FROM table_cards WHERE ID = ".$card_id;
	
	if ($mysqli->query($sql) === TRUE) 
	{
		$sql = "DELETE FROM table_analytics WHERE CID = ".$card_id;
		$mysqli->query($sql);
		$resText = "Card deleted";
	}
	else 
	{
		$resText = "Database error";
	}
}
echo "<hr>".$resText;


/* Fermeture de la connexion */
$mysqli->close();
?>
	</div>
</body>
</html>