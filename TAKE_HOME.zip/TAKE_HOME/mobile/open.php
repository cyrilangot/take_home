<?php
$mysqli = new mysqli("localhost", "root", "", "");

/* check connecton state*/
if ($mysqli->connect_errno) 
{
	echo "<Rslt>Error</Rslt>";
    exit();
}

$bReady = true;
// Create database
$sql="CREATE DATABASE IF NOT EXISTS _mobile";
if (mysqli_query($mysqli, $sql))
{
	//echo "Database _mobile created successfully<br><br>";
	
	mysqli_select_db($mysqli, "_mobile");

    $sql_user = "CREATE TABLE IF NOT EXISTS table_users (
		ID INT(8) UNSIGNED AUTO_INCREMENT PRIMARY KEY,  
		NAME VARCHAR(30) NOT NULL, 
		MAIL VARCHAR(30) NOT NULL, 
		PWD VARCHAR(30) NOT NULL)";

    $sql_cards = "CREATE TABLE IF NOT EXISTS table_cards (
            ID INT(8) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            UID INT(8) UNSIGNED,
            TYPE INT(8) UNSIGNED,
            NAME VARCHAR(30) NOT NULL,
            SUMMARY VARCHAR(30) NOT NULL)";

    $sql_analytics = "CREATE TABLE IF NOT EXISTS table_analytics (
            ID INT(8) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            CID INT(8) UNSIGNED,
            DATA VARCHAR(100) NOT NULL)";

	if ($mysqli->query($sql_user) === TRUE) 
	{
		//echo "Table table_users created successfully<br>";
	} 
	else 
	{
		$bReady = false;
	}
	if ($mysqli->query($sql_cards) === TRUE) 
	{
		//echo "Table table_cards created successfully<br>";
	} 
	else 
	{
		$bReady = false;
	}

	if ($mysqli->query($sql_analytics) === TRUE) 
	{
		//echo "Table table_analytics created successfully<br>";
	} 
	else 
	{
		$bReady = false;
	}
	
	if ($bReady == true)
	{
		echo "<Rslt>Ok</Rslt>";
	}
	else
	{
		echo "<Rslt>Error</Rslt>";
	}
}
else
{
	echo "<Rslt>Error</Rslt>";
}

/* Fermeture de la connexion */
$mysqli->close();
?>
