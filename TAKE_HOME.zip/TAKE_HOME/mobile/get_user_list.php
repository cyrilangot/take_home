<?php
$mysqli = new mysqli("localhost", "root", "", "_mobile");

/* check connecton state*/
if ($mysqli->connect_errno) 
{
	echo "<Rslt>Error</Rslt>";
    exit();
}
else
{
	$mode = 0;
	if (isset($_GET["mode"]))
	{
		$mode = $_GET["mode"];
	}

	$req = "SELECT * FROM table_users";

	$result = $mysqli->query($req);
	
	$switch = true;

	if ($mode == 0)
	{
		echo "<table  border='1'>";
		echo "<tr><th width = '100px' align='left'>NAME</th><th width='200px' align='left'>MAIL</th></tr>";

		while($row = mysqli_fetch_array($result)) 
		{
			if ($switch == true)
			{
				$color = "bgcolor='#D0D0D0'";
			}
			else
			{
				$color = "bgcolor='#A0A0A0'";
			}
			$switch = !$switch;
			
			$name = $row['NAME'];
			$mail = $row['MAIL'];
			echo "<tr ".$color."><td>".$name."</td><td>".$mail."</td></tr>";
		} 	
				
		echo "</table>";
	}
	else 
	{
		echo "<users>\n";

		while($row = mysqli_fetch_array($result)) 
		{
			$name = $row['NAME'];
			$mail = $row['MAIL'];
			echo "<user name='".$name."' mail='".$mail."'>\n";
		} 	
				
		echo "</users>\n";
	}
}


/* Fermeture de la connexion */
$mysqli->close();
?>
