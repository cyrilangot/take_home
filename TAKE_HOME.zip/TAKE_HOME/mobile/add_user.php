<?php
$mysqli = new mysqli("localhost", "root", "", "_mobile");

/* check connecton state*/
if ($mysqli->connect_errno) 
{
	echo "<Rslt>Error</Rslt>";
    exit();
}
else
{
	if (isset($_GET["name"]) && isset($_GET["mail"]) && isset($_GET["pwd"]))
	{
		$name = $_GET["name"];
		$mail = $_GET["mail"];
		$pwd = $_GET["pwd"];
		$reqexists = sprintf("SELECT * FROM table_users WHERE NAME='%s' AND MAIL='%s'", $name, $mail);
	
		$result = $mysqli->query($reqexists);
		//$data = $result->fetch();

		$row_cnt = mysqli_num_rows($result);
		mysqli_free_result($result);
		
		if ($row_cnt > 0)
		{
			echo "<Rslt>Exists</Rslt>";
		}
		else
		{
			$sql = "INSERT INTO table_users (NAME, MAIL, PWD) VALUES ('".$name."', '".$mail."', '".$pwd."')";

			if ($mysqli->query($sql) === TRUE) 
			{
				echo "<Rslt>Ok</Rslt>";
			}
			else 
			{
				echo "<Rslt>Error</Rslt>";
			}
		}
		
	}
	else
	{
		echo "<Rslt>Error</Rslt>";
	}
}

$bReady = true;

/* Fermeture de la connexion */
$mysqli->close();
?>
