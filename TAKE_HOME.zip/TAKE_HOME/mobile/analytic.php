<!DOCTYPE html>
<html>
<head>
	<title>Mobile</title>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width">
</head>

<body>

<?php
$mysqli = new mysqli("localhost", "root", "", "_mobile");

/* check connecton state*/
if ($mysqli->connect_errno) 
{
    printf("Database connect error: %s\n", $mysqli->connect_error);
    exit();
}


if (isset($_GET["card_id"]))
{
	$card_id = $_GET["card_id"];
}
else
{
	exit();
}

$reqexists = sprintf("SELECT * FROM table_analytics WHERE CID='%s'", $card_id);
$result = $mysqli->query($reqexists);

$row = mysqli_fetch_array($result);
	
$analytic = $row['DATA'];


echo "<b>Edit analytics:</b><br>";
?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
  <div>
    <textarea id="data" name="data" rows="5" cols="33"><?php echo $analytic; ?></textarea>
	
	<button type="submit">Update</button>
	<input type="hidden" id="card_id" name="card_id" value="<?php echo $card_id?>">
	<input type="hidden" id="action" name="action" value="1">
  </div>
</form>	
<?php

$resText =  "";
$action = 0;
if (isset($_GET["action"])) $action = $_GET["action"];
if ($action == 1)
{
	$data = $_GET["data"];

	$sql = "UPDATE table_analytics SET DATA='".$data."' WHERE CID=".$card_id;

	if ($mysqli->query($sql) === TRUE) 
	{
		$resText = "Analytic updated";
	}
	else 
	{
		$resText = "Database error";
	}
}

echo "<hr>".$resText;

/* Fermeture de la connexion */
$mysqli->close();
?>
	</div>
</body>
</html>