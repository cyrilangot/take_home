package com.example.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import database.DataManager;
import database.SQLiteDataManager;

public class CardActivity extends AppCompatActivity
{
    ListView m_ListView;

    public class UserDescAdapter extends ArrayAdapter<DataManager.CardDesc>
    {
        private final Context m_context;
        private List<DataManager.CardDesc> m_ListCardDesc;

        public UserDescAdapter(Context context, int resource, List<DataManager.CardDesc> listCardDesc)
        {
            super(context, resource, listCardDesc);
            m_context = context;
            m_ListCardDesc = listCardDesc;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent)
        {
            final DataManager.CardDesc aCardDesc = m_ListCardDesc.get(position);

            if (convertView == null)
            {
                LayoutInflater inflater = (LayoutInflater) m_context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.card_line, parent, false);

                convertView.setOnClickListener(new View.OnClickListener()
                {
                    public DataManager.CardDesc m_CardDesc = aCardDesc;
                    @Override
                    public void onClick(View v)
                    {
                        DataManager.m_pstCurrentCardDesc = m_CardDesc;
                        startActivity(new Intent(CardActivity.this, ViewCardActivity.class));
                    }
                });
            }
            else
            {
                convertView = (RelativeLayout) convertView;
            }

            TextView viewName = (TextView) convertView.findViewById(R.id.card_name);
            viewName.setText(aCardDesc.m_szName);

            TextView viewMail = (TextView) convertView.findViewById(R.id.card_summary);
            viewMail.setText(aCardDesc.m_szSummary);

            ImageView aImageView = convertView.findViewById(R.id.avatar);
            if (aCardDesc.m_iType == DataManager.TYPE_VISA)
            {
                Bitmap bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.visa);
                // Set image as bitmap for fourth ImageView
                aImageView.setImageBitmap(bitmap);
            }
            else
            {
                Bitmap bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.master);
                // Set image as bitmap for fourth ImageView
                aImageView.setImageBitmap(bitmap);
            }

            Button aButton =  convertView.findViewById(R.id.buttonCardDelete);
            aButton.setOnClickListener(new View.OnClickListener()
            {
                public int m_iCardID = aCardDesc.m_iCardID;
                @Override
                public void onClick(View v)
                {
                    DataManager.GetDataManager().DeleteCard(m_iCardID);
                    PopulateList();
                }
            });

            return convertView;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listcard);

        DataManager aDataManager = new SQLiteDataManager(this);
        aDataManager.open();

        ((TextView)findViewById(R.id.textViewCurrentUser)).setText("Current User: " + DataManager.GetCurrentUserDesc().m_szUserName);

        m_ListView = (ListView) findViewById(R.id.listView);

        PopulateList();

        Button ButtonAdd = (Button) findViewById(R.id.buttonAdd);
        ButtonAdd.setOnClickListener((new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                AddCard();
            }
        }));
    }

    protected void PopulateList()
    {
        List<DataManager.CardDesc> aList = DataManager.GetDataManager().GetCurrentUserCardList();

        UserDescAdapter adapter = new UserDescAdapter(getApplicationContext(), R.layout.card_line, aList);
        m_ListView.setAdapter(adapter);
    }

    protected void AddCard()
    {
        startActivityForResult(new Intent(CardActivity.this, AddCardActivity.class), 1);
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        return super.onOptionsItemSelected(item);
    }

    protected void onActivityResult (int requestCode, int resultCode, Intent data)
    {
        if (Activity.RESULT_OK == resultCode)
        {
            PopulateList();
        }
    }

}
