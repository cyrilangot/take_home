package com.example.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import database.DataManager;

public class AddUserActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_user);

        Button ButtonAdd = findViewById(R.id.buttonAdd);
        ButtonAdd.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                String szName =  ((EditText) findViewById(R.id.editTextName)).getText().toString();
                String szMail =  ((EditText) findViewById(R.id.editTextMail)).getText().toString();
                String szPwd =  ((EditText) findViewById(R.id.editTextPwd)).getText().toString();

                int iRetValue  = DataManager.GetDataManager().InsertUser(szName, szMail, szPwd);

                switch (iRetValue)
                {
                    case DataManager.INSERT_USER_SUCCESS:
                    {
                        Intent returnIntent = new Intent();
                        setResult(Activity.RESULT_OK,returnIntent);
                        finish();
                        break;
                    }
                    case DataManager.INSERT_USER_EXIST:
                    {
                        Context context = getApplicationContext();
                        CharSequence text = "User Exists!";
                        int duration = Toast.LENGTH_SHORT;

                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                        break;
                    }
                    case DataManager.INSERT_USER_ERROR:
                    {
                        Context context = getApplicationContext();
                        CharSequence text = "Insert Error!";
                        int duration = Toast.LENGTH_SHORT;

                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                        break;
                    }
                }
            }
        });

    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        return super.onOptionsItemSelected(item);
    }
}
