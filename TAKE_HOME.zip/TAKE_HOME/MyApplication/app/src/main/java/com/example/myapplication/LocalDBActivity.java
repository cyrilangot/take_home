package com.example.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import database.DataManager;
import database.SQLiteDataManager;

public class LocalDBActivity extends AppCompatActivity
{
    ListView m_ListView;

    public class UserDescAdapter extends ArrayAdapter<DataManager.UserDesc>
    {
        private final Context m_context;
        private List<DataManager.UserDesc> m_ListUserDesc;

        public UserDescAdapter(Context context, int resource, List<DataManager.UserDesc> listUserDesc)
        {
            super(context, resource, listUserDesc);
            m_context = context;
            m_ListUserDesc = listUserDesc;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent)
        {
            final DataManager.UserDesc aUserDesc = m_ListUserDesc.get(position);

            if (convertView == null)
            {
                LayoutInflater inflater = (LayoutInflater) m_context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.user_line, parent, false);

                convertView.setOnClickListener(new View.OnClickListener()
                {
                    public DataManager.UserDesc m_UserDesc = aUserDesc;
                    @Override
                    public void onClick(View v)
                    {
                        DataManager.m_pstCurrentUserDesc = m_UserDesc;
                        startActivity(new Intent(LocalDBActivity.this, CardActivity.class));
                    }
                });
            }
            else
            {
                convertView = (RelativeLayout) convertView;
            }

            TextView viewName = (TextView) convertView.findViewById(R.id.card_name);
            viewName.setText(aUserDesc.m_szUserName);

            TextView viewMail = (TextView) convertView.findViewById(R.id.card_summary);
            viewMail.setText(aUserDesc.m_szUserMail);

            return convertView;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_localdb_main);

        DataManager aDataManager = new SQLiteDataManager(this);
        aDataManager.open();

        m_ListView = (ListView) findViewById(R.id.listView);

        PopulateList();

        Button ButtonAdd = (Button) findViewById(R.id.buttonAdd);
        ButtonAdd.setOnClickListener((new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                AddUser();
            }
        }));
    }

    protected void PopulateList()
    {
        List<DataManager.UserDesc> aList = DataManager.GetDataManager().GetUserList();

        UserDescAdapter adapter = new UserDescAdapter(getApplicationContext(), R.layout.user_line, aList);
        m_ListView.setAdapter(adapter);
    }

    protected void AddUser()
    {
        startActivityForResult(new Intent(LocalDBActivity.this, AddUserActivity.class), 1);
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        return super.onOptionsItemSelected(item);
    }

    protected void onActivityResult (int requestCode, int resultCode, Intent data)
    {
        if (Activity.RESULT_OK == resultCode)
        {
            PopulateList();
        }
    }

}
