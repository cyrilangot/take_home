package com.example.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import database.DataManager;

public class AddCardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_card);

        Button ButtonAdd = findViewById(R.id.buttonAdd);
        ButtonAdd.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                String szName =  ((EditText) findViewById(R.id.editTextName)).getText().toString();
                String szSummary =  ((EditText) findViewById(R.id.editTextSummary)).getText().toString();

                RadioButton aRadioButton = findViewById(R.id.radioButtonVisa);
                int iType = 0;
                if (aRadioButton.isChecked())
                {
                    iType = DataManager.TYPE_VISA;
                }
                else
                {
                    iType = DataManager.TYPE_MASTER_CARD;
                }

                String szAnalytic = ((EditText) findViewById(R.id.editTextAnalytic)).getText().toString();

                int iRetValue  = DataManager.GetDataManager().InsertCard(szName, DataManager.GetCurrentUserDesc().m_iUserID, iType, szSummary, szAnalytic);

                switch (iRetValue)
                {
                    case DataManager.INSERT_CARD_SUCCESS:
                    {
                        Intent returnIntent = new Intent();
                        setResult(Activity.RESULT_OK, returnIntent);
                        finish();
                        break;
                    }
                    case DataManager.INSERT_CARD_EXIST:
                    {
                        Context context = getApplicationContext();
                        CharSequence text = "Card Exists!";
                        int duration = Toast.LENGTH_SHORT;

                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                        break;
                    }
                    case DataManager.INSERT_CARD_ERROR:
                    {
                        Context context = getApplicationContext();
                        CharSequence text = "Insert Card Error!";
                        int duration = Toast.LENGTH_SHORT;

                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                        break;
                    }
                }
            }
        });

    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        return super.onOptionsItemSelected(item);
    }
}
