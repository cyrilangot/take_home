package com.example.myapplication;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnShowListener;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import database.DataManager;
import database.ServerDataManager;

public class ServerActivity extends AppCompatActivity
{
    protected EditText EditTextName = null;
    protected EditText EditTextPwd = null;
    protected TextView TextViewState = null;

    ListView m_ListView;
    List<DataManager.CardDesc> m_ListCardDesc = null;

    static final int PROGRESS_DIALOG_CONNECT = 1;
    static final int CONNECTENDED = 0;

    public static final int CONNECT_OK = 0;
    public static final int CONNECT_ERROR = 1;

    //pop up de download
    ProgressDialog m_progressDialog = null;

    //thread de download
    ProgressThreadConnect m_progressThreadConnect = null;

    public boolean m_bCancelLogin = false;

    //etat de la connection reseau
    boolean m_bConnectState = false;
    int m_iConnectResult;

    protected String m_szLogin;
    protected String m_szPWD;

    public class UserDescAdapter extends ArrayAdapter<DataManager.CardDesc>
    {
        private final Context m_context;
        private List<DataManager.CardDesc> m_ListCardDesc;

        public UserDescAdapter(Context context, int resource, List<DataManager.CardDesc> listCardDesc)
        {
            super(context, resource, listCardDesc);
            m_context = context;
            m_ListCardDesc = listCardDesc;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent)
        {
            final DataManager.CardDesc aCardDesc = m_ListCardDesc.get(position);

            if (convertView == null)
            {
                LayoutInflater inflater = (LayoutInflater) m_context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.card_line, parent, false);

                convertView.setOnClickListener(new View.OnClickListener()
                {
                    public DataManager.CardDesc m_CardDesc = aCardDesc;
                    @Override
                    public void onClick(View v)
                    {
                        DataManager.m_pstCurrentCardDesc = m_CardDesc;
                        startActivity(new Intent(ServerActivity.this, ViewCardActivity.class));
                    }
                });
            }
            else
            {
                convertView = (RelativeLayout) convertView;
            }

            TextView viewName = (TextView) convertView.findViewById(R.id.card_name);
            viewName.setText(aCardDesc.m_szName);

            TextView viewMail = (TextView) convertView.findViewById(R.id.card_summary);
            viewMail.setText(aCardDesc.m_szSummary);

            Button aButton =  convertView.findViewById(R.id.buttonCardDelete);
            aButton.setOnClickListener(new View.OnClickListener()
            {
                public int m_iCardID = aCardDesc.m_iCardID;
                @Override
                public void onClick(View v)
                {
                    DataManager.GetDataManager().DeleteCard(m_iCardID);
                    PopulateList();
                }
            });

            return convertView;
        }
    }

    //classe implementant le thread de connection
    private class ProgressThreadConnect extends Thread
    {
        Handler m_Handler;

        ProgressThreadConnect(Handler h)
        {
            m_Handler = h;
        }

        public void run()
        {
            dialogConnect();
            Message msg = m_Handler.obtainMessage();
            msg.arg1 = CONNECTENDED;
            m_Handler.sendMessage(msg);
        }
    }

    // Define the Handler that receives messages from the thread and update the progress
    final Handler m_ConnectHandler = new Handler()
    {
        public void handleMessage(Message msg)
        {
            if (msg.arg1 == CONNECTENDED)
            {
                switch (m_iConnectResult)
                {
                    case DataManager.CONNECT_OK:
                    {
                        TextViewState.setText("Connected");
                        dismissDialog(PROGRESS_DIALOG_CONNECT);
                        PopulateList();
                        break;
                    }
                    case DataManager.CONNECT_ERROR:
                    {
                        TextViewState.setText("Connection error");
                        dismissDialog(PROGRESS_DIALOG_CONNECT);
                        break;
                    }
                    case DataManager.CONNECT_PWD_ERROR:
                    {
                        TextViewState.setText("Pwd error");
                        dismissDialog(PROGRESS_DIALOG_CONNECT);
                        break;
                    }
                }
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_server_main);

        String szBaseServerUrl = "";
        SharedPreferences aSharedPreferences = getSharedPreferences("OfflineInfo", Activity.MODE_PRIVATE);
        if (aSharedPreferences != null)
        {
            szBaseServerUrl = aSharedPreferences.getString("urlserver", "");
        }

        DataManager aDataManager = new ServerDataManager(this, szBaseServerUrl);

        Button ButtonConnect = findViewById(R.id.buttonConnect);
        ButtonConnect.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                Connect();
            }
        });

        EditTextName = (EditText) findViewById(R.id.editTextName);
        EditTextPwd =  (EditText) findViewById(R.id.editTextPwd);
        TextViewState = (TextView) findViewById(R.id.textViewState);

        m_ListView = (ListView) findViewById(R.id.listView);
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        return super.onOptionsItemSelected(item);
    }

    private void Connect()
    {
        m_szLogin = EditTextName.getText().toString();
        m_szPWD = EditTextPwd.getText().toString();

        showDialog(PROGRESS_DIALOG_CONNECT);

    }

    protected void dialogConnect()
    {
        //on teste si les InputText sont vides ou non
        if (!((m_szLogin == null) || m_szLogin.equals("") || (m_szPWD == null) || m_szPWD.equals("")))
        {
            if (DataManager.GetDataManager().open() == DataManager.OPEN_OK)
            {
                ServerDataManager aServerDataManager = (ServerDataManager)(DataManager.GetDataManager());
                m_iConnectResult = aServerDataManager.Connect(m_szLogin, m_szPWD);

                if (m_iConnectResult == DataManager.CONNECT_OK)
                {
                    m_ListCardDesc = DataManager.GetDataManager().GetCurrentUserCardList();
                }
            }
            else
            {
                m_iConnectResult = DataManager.CONNECT_ERROR;
            }
        }
    }

    protected Dialog onCreateDialog(int id)
    {
        switch(id)
        {
            case PROGRESS_DIALOG_CONNECT:
            {
                m_bCancelLogin = false;
                m_progressDialog = new ProgressDialog(this);
                m_progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                m_progressDialog.setTitle("Wait");
                m_progressDialog.setIcon(null);

                m_progressDialog.setOnShowListener(new OnShowListener()
                {
                    @Override
                    public void onShow(DialogInterface dialog)
                    {
                        //dialogConnect();
                    }
                });

                m_progressDialog.setOnCancelListener(new OnCancelListener()
                {
                    @Override
                    public void onCancel(DialogInterface arg0)
                    {
                        //le download a ete annule on detruit le repertoire de destination pour permettre de refaire completement le download
                        m_bCancelLogin = true;
                    }
                });

                m_progressDialog.setOnDismissListener(new OnDismissListener()
                {
                    @Override
                    public void onDismiss(DialogInterface dialog)
                    {
                        //m_progressThreadConnect;
                    }
                });
                return m_progressDialog;
            }

            default:
            {
                //Log.e("Event", "onStart");
                return null;
            }
        }
    }

    @Override
    protected void onPrepareDialog(int id, Dialog dialog)
    {
        switch(id)
        {
            case PROGRESS_DIALOG_CONNECT:
            {
                m_progressThreadConnect = new ProgressThreadConnect(m_ConnectHandler);
                m_progressThreadConnect.start();
                break;
            }
        }
    }

    protected void PopulateList()
    {
        ServerActivity.UserDescAdapter adapter = new ServerActivity.UserDescAdapter(getApplicationContext(), R.layout.card_line, m_ListCardDesc);
        m_ListView.setAdapter(adapter);
    }

}
