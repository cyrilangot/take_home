package com.example.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import database.DataManager;

public class ViewCardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_card);

        EditText EditTextName  =  ((EditText) findViewById(R.id.editTextName));
        EditText EditTextSummary  =  ((EditText) findViewById(R.id.editTextSummary));
        EditText EditTextAnalytic  =  ((EditText) findViewById(R.id.editTextAnalytic));

        EditTextName.setEnabled(false);
        EditTextName.setKeyListener(null);
        EditTextSummary.setEnabled(false);
        EditTextSummary.setKeyListener(null);
        EditTextAnalytic.setEnabled(false);
        EditTextAnalytic.setKeyListener(null);

        EditTextName.setText(DataManager.GetCurrentCardDesc().m_szName);
        EditTextSummary.setText(DataManager.GetCurrentCardDesc().m_szSummary);
        EditTextAnalytic.setText(DataManager.GetDataManager().GetAnalytics(DataManager.GetCurrentCardDesc().m_iCardID));
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        return super.onOptionsItemSelected(item);
    }
}
