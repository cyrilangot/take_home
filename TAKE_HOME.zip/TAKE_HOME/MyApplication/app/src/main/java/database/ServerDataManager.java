package database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

public class ServerDataManager extends DataManager
{
    private static final int VERSION_BDD = 1;
    private static final String NOM_BDD = "local.db";

    private String m_szBaseServerUrl = "";
    private String m_szServerUrl = "";

    private List<CardDesc> m_ListCard = null;

    public ServerDataManager(Context context, String szBaseServerUrl)
    {
        super(context);
        m_szBaseServerUrl = szBaseServerUrl;
        m_szServerUrl = m_szBaseServerUrl + "/mobile";
        m_pstDataManager = this;
    }

    @Override
    public int open()
    {
        //on ouvre la BDD en écriture
        String szRes = CallWebService(m_szServerUrl + "/service_open.php");

        if ((szRes != null) && szRes.equals("<Rslt>Ok</Rslt>"))
        {
            return OPEN_OK;
        }
        else
        {
            return OPEN_ERROR;
        }
    }

    public int Connect(String szName, String szPwd)
    {
        String szRes = CallWebService(m_szServerUrl + "/service_connect_user.php?name=" + szName + "&pwd=" + szPwd);

        if ((szRes != null) && szRes.equals("<Rslt>Error</Rslt>"))
        {
            return DataManager.CONNECT_ERROR;
        }
        else
        {
            szRes = szRes.substring(szRes.indexOf('>') + 1);
            szRes = szRes.substring(0, szRes.indexOf('<'));
            int iID = Integer.parseInt(szRes);

            m_ListCard = new ArrayList<CardDesc>();
            if (iID == -1)
            {
                return DataManager.CONNECT_PWD_ERROR;
            }
            else
            {
                UserDesc aUserDesc = new UserDesc();
                aUserDesc.m_iUserID = iID;
                aUserDesc.m_szUserName = szName;
                aUserDesc.m_szUserMail = "";

                m_pstCurrentUserDesc = aUserDesc;

                return DataManager.CONNECT_OK;
            }
        }
    }

    @Override
    public void close()
    {
        //on ferme l'accès à la BDD
    }

    @Override
    public int InsertUser(String szUserName, String szUserMail, String szPwd)
    {
        return DataManager.INSERT_USER_ERROR;
    }

    @Override
    public List<UserDesc> GetUserList()
    {
        List<UserDesc> retValue = new ArrayList<UserDesc>();
        return retValue;
    }

    @Override
    public List<CardDesc> GetCurrentUserCardList()
    {
        String szRes = CallWebService(m_szServerUrl + "/service_list_card.php?user_id=" + m_pstCurrentUserDesc.m_iUserID);
        List<CardDesc> retValue = new ArrayList<CardDesc>();

        boolean bContinue = true;
        szRes = szRes.substring(szRes.indexOf('<') + 1);

        while (bContinue)
        {
            szRes = szRes.substring(szRes.indexOf('<') + 1);
            if (szRes.charAt(0) == '/')
            {
                bContinue = false;
            }
            else
            {
                String szLine = szRes.substring(0, szRes.indexOf('>'));
                String[] szTokens = szLine.split(" ");

                String aToken = szTokens[1];
                int iId = Integer.parseInt(aToken.substring(aToken.indexOf('\'') + 1, aToken.lastIndexOf('\'')));

                aToken = szTokens[2];
                String szName = aToken.substring(aToken.indexOf('\'') + 1, aToken.lastIndexOf('\''));

                aToken = szTokens[3];
                String szSummary = aToken.substring(aToken.indexOf('\'') + 1, aToken.lastIndexOf('\''));

                aToken = szTokens[4];
                String szType = aToken.substring(aToken.indexOf('\'') + 1, aToken.lastIndexOf('\''));
                int iType;
                if (szType.equals("visa"))
                {
                    iType = TYPE_VISA;
                }
                else
                {
                    iType = TYPE_MASTER_CARD;
                }

                CardDesc aCardDesc = new CardDesc();
                aCardDesc.m_iCardID = iId;
                aCardDesc.m_iUserID = m_pstCurrentUserDesc.m_iUserID;
                aCardDesc.m_iType = iType;
                aCardDesc.m_szName = szName;
                aCardDesc.m_szSummary = szSummary;

                retValue.add(aCardDesc);
            }
        }

        return retValue;
    }

    @Override
    public int InsertCard(String szCardName, int iUserID, int iType, String szSummary, String szAnalytic)
    {
        return DataManager.INSERT_CARD_ERROR;
    }

    @Override
    public int DeleteCard(int iCardID)
    {
        String szRes = CallWebService(m_szServerUrl + "/service_delete_card.php?card_id=" + iCardID);
        if ((szRes != null) && szRes.equals("<Rslt>Error</Rslt>"))
        {
            return DataManager.DELETE_CARD_ERROR;
        }
        else
        {
            return DataManager.DELETE_CARD_SUCCESS;
        }
    }

    @Override
    public int InsertAnalytics(int iCardID, String szDATA)
    {
        return INSERT_ANALYTIC_ERROR;
    }

    @Override
    public int DeleteAnalytics(int iCardID)
    {
        return DELETE_ANALYTIC_ERROR;
    }

    @Override
    public String GetAnalytics(int iCardID)
    {
            return "** Analytics error**";
    }

    @Override
    public int UpdateAnalytics(int iCardID, String szData)
    {
        return UPDATE_ANALYTIC_ERROR;
    }

    //Call web services and return response string
    private String CallWebService(String url)//, String soapAction, String envelope)
    {
        String responseString = "";
        try
        {
            //URL aURL = new URL("http://192.168.1.10/mobile/open.php");
            URL aURL = new URL("http://" + url);
            BufferedReader reader = new BufferedReader(new InputStreamReader(aURL.openStream()));
            String line;
            while ((line = reader.readLine()) != null)
            {
                responseString += line;
            }
            reader.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        // close the connection
        return responseString;
    }

}
