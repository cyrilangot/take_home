package database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class SQLiteDataManager extends DataManager
{
    private static final int VERSION_BDD = 1;
    private static final String NOM_BDD = "local.db";

    private SQLiteDatabase m_bdd;
    private CustomSQLite m_CustomSQLite;

    public SQLiteDataManager(Context context)
    {
        super(context);
        m_CustomSQLite = new CustomSQLite(context, NOM_BDD, null, VERSION_BDD);
        m_pstDataManager = this;
    }

    @Override
    public int open()
    {
        //on ouvre la BDD en écriture
        m_bdd = m_CustomSQLite.getWritableDatabase();
        return OPEN_OK;
    }

    @Override
    public void close()
    {
        //on ferme l'accès à la BDD
        m_bdd.close();
    }

    @Override
    public int InsertUser(String szUserName, String szUserMail, String szPwd)
    {
        m_bdd = m_CustomSQLite.getWritableDatabase();

        String szQuery = "select * from table_users where " + CustomSQLite.COL_NAME + " = ?";
        Cursor c = m_bdd.rawQuery(szQuery, new String[] {szUserName});
        if (c.getCount() != 0)
        {
            return DataManager.INSERT_USER_EXIST;
        }

        ContentValues values = new ContentValues();

        values.put(CustomSQLite.COL_NAME, szUserName);
        values.put(CustomSQLite.COL_MAIL, szUserMail);
        values.put(CustomSQLite.COL_PWD, szPwd);
        //on insère l'objet dans la BDD via le ContentValues
        long iRetValue = m_bdd.insert(CustomSQLite.TABLE_USERS, null, values);

        if (iRetValue == -1)
        {
            return DataManager.INSERT_USER_ERROR;
        }
        else
        {
            return DataManager.INSERT_USER_SUCCESS;
        }
    }

    @Override
    public List<UserDesc> GetUserList()
    {
        m_bdd = m_CustomSQLite.getWritableDatabase();
        Cursor c = m_bdd.rawQuery("select * from table_users", null);

        List<UserDesc> retValue = new ArrayList<UserDesc>();
        while (c.moveToNext())
        {
            UserDesc aUserDesc = new UserDesc();
            aUserDesc.m_iUserID = c.getInt(0);
            aUserDesc.m_szUserName = c.getString(1);
            aUserDesc.m_szUserMail = c.getString(2);
            retValue.add(aUserDesc);
        }
        return retValue;
    }

    @Override
    public List<CardDesc> GetCurrentUserCardList()
    {
        m_bdd = m_CustomSQLite.getWritableDatabase();
        String szQuery = "select * from table_cards where " + CustomSQLite.COL_CARD_USER_ID + " = ?";
        Cursor c = m_bdd.rawQuery(szQuery , new String[] {Integer.toString(m_pstCurrentUserDesc.m_iUserID)});

        List<CardDesc> retValue = new ArrayList<CardDesc>();
        while (c.moveToNext())
        {
            CardDesc aCardDesc = new CardDesc();
            aCardDesc.m_iCardID = c.getInt(0);
            aCardDesc.m_iUserID = c.getInt(1);
            aCardDesc.m_iType = c.getInt(2);
            aCardDesc.m_szName = c.getString(3);
            aCardDesc.m_szSummary = c.getString(4);
            retValue.add(aCardDesc);
        }
        return retValue;
    }

    @Override
    public int InsertCard(String szCardName, int iUserID, int iType, String szSummary, String szAnalytic)
    {
        if ((szSummary == null) || (szSummary == ""))
        {
            szSummary = DEFAULT_SUMMARY;
        }

        if ((szAnalytic == null) || (szAnalytic == ""))
        {
            szAnalytic = DEFAULT_ANALYTIC;
        }

        m_bdd = m_CustomSQLite.getWritableDatabase();

        String szQuery = "select * from table_cards where " + CustomSQLite.COL_NAME + " = ?";
        Cursor c = m_bdd.rawQuery(szQuery, new String[] {szCardName});
        if (c.getCount() != 0)
        {
            return DataManager.INSERT_CARD_EXIST;
        }

        ContentValues values = new ContentValues();

        values.put(CustomSQLite.COL_NAME, szCardName);
        values.put(CustomSQLite.COL_CARD_SUMMARY, szSummary);
        values.put(CustomSQLite.COL_CARD_TYPE, iType);
        values.put(CustomSQLite.COL_CARD_USER_ID, iUserID);

        long iRetValue = m_bdd.insert(CustomSQLite.TABLE_CARDS, null, values);

        if (iRetValue == -1)
        {
            return DataManager.INSERT_CARD_ERROR;
        }
        else
        {
            values = new ContentValues();
            values.put(CustomSQLite.COL_CARD_ID, iRetValue);
            values.put(CustomSQLite.COL_ANALYTICS_DATA, szAnalytic);

            iRetValue = m_bdd.insert(CustomSQLite.TABLE_ANALYTICS, null, values);
            if (iRetValue == -1)
            {
                return DataManager.INSERT_CARD_ERROR;
            }
            else
            {
                return DataManager.INSERT_CARD_SUCCESS;
            }
        }
    }

    @Override
    public int DeleteCard(int iCardID)
    {
        m_bdd = m_CustomSQLite.getWritableDatabase();
/*
        String szQuery = "select * from table_analytics ";
        Cursor c = m_bdd.rawQuery(szQuery , null);

        while (c.moveToNext())
        {
            int i1 = c.getInt(0);
            int i2 = c.getInt(1);
            String s = c.getString(2);
        }
*/
        long iRetValue = m_bdd.delete("table_cards", CustomSQLite.COL_ID + " = ?", new String[]{Integer.toString(iCardID)});
        if (iRetValue == -1)
        {
            return DataManager.DELETE_CARD_ERROR;
        }
        else
        {
            iRetValue = m_bdd.delete("table_analytics", CustomSQLite.COL_CARD_ID + " = ?", new String[]{Integer.toString(iCardID)});
            if (iRetValue == -1)
            {
                return DataManager.DELETE_CARD_ERROR;
            }
            else
            {
                return DataManager.DELETE_CARD_SUCCESS;
            }
        }
    }

    @Override
    public int InsertAnalytics(int iCardID, String szDATA)
    {
        return INSERT_ANALYTIC_ERROR;
    }

    @Override
    public int DeleteAnalytics(int iCardID)
    {
        return DELETE_ANALYTIC_ERROR;
    }

    @Override
    public String GetAnalytics(int iCardID)
    {
        m_bdd = m_CustomSQLite.getWritableDatabase();
        String szQuery = "select * from table_analytics where " + CustomSQLite.COL_CARD_ID + " = ?";
        Cursor c = m_bdd.rawQuery(szQuery , new String[] {Integer.toString(iCardID)});

        if (c.getCount() == 0)
        {
            return "** Analytics error**";
        }
        else
        {
            c.moveToFirst();
            return c.getString(2);
        }
    }

    @Override
    public int UpdateAnalytics(int iCardID, String szData)
    {
        return UPDATE_ANALYTIC_ERROR;
    }


}
