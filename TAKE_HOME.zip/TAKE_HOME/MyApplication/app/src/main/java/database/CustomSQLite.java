package database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;

public class CustomSQLite extends SQLiteOpenHelper
{
    public static final String TABLE_USERS = "table_users";
    public static final String COL_ID = "ID";
    public static final String COL_NAME = "NAME";
    public static final String COL_MAIL = "MAIL";
    public static final String COL_PWD = "PWD";

    public static final String TABLE_CARDS = "table_cards";
    public static final String COL_CARD_TYPE = "TYPE";
    public static final String COL_CARD_USER_ID = "UID";
    public static final String COL_CARD_SUMMARY = "SUMMARY";

    public static final String TABLE_ANALYTICS = "table_analytics";
    public static final String COL_CARD_ID = "CID";
    public static final String COL_ANALYTICS_DATA = "DATA";

    private static final String CREATE_TABLE_USERS = "CREATE TABLE " + TABLE_USERS + " ("
            + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COL_NAME + " TEXT NOT NULL, "
            + COL_MAIL + " TEXT NOT NULL, "
            + COL_PWD + " TEXT NOT NULL);";

    private static final String CREATE_TABLE_CARDS = "CREATE TABLE " + TABLE_CARDS + " ("
            + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COL_CARD_USER_ID + " INTEGER, "
            + COL_CARD_TYPE + " INTEGER, "
            + COL_NAME + " TEXT NOT NULL, "
            + COL_CARD_SUMMARY + " TEXT NOT NULL);";

    private static final String CREATE_TABLE_ANALYTICS = "CREATE TABLE " + TABLE_ANALYTICS + " ("
            + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COL_CARD_ID + " INTEGER, "
            + COL_ANALYTICS_DATA + " TEXT NOT NULL);";

    public CustomSQLite(Context context, String name, CursorFactory factory, int version)
    {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_CARDS);
        db.execSQL(CREATE_TABLE_ANALYTICS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("DROP TABLE " + TABLE_USERS + ";");
        db.execSQL("DROP TABLE " + TABLE_CARDS + ";");
        db.execSQL("DROP TABLE " + TABLE_ANALYTICS + ";");
        onCreate(db);
    }
}
