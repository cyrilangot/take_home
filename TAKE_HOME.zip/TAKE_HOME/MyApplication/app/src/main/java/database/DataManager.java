package database;

import android.content.Context;

import java.util.List;

public class DataManager
{
    public static final int OPEN_OK = 1;
    public static final int OPEN_ERROR = 0;

    public static final int CONNECT_OK = 0;
    public static final int CONNECT_ERROR = 1;
    public static final int CONNECT_PWD_ERROR = 2;
    public static final int CONNECT_BAD_ADDR_ERROR = 3;
    public static final int CONNECT_TIME_OUT = 30000;

    public static final int INSERT_USER_ERROR = 0;
    public static final int INSERT_USER_SUCCESS = 1;
    public static final int INSERT_USER_EXIST = 2;

    public static final int INSERT_CARD_ERROR = 0;
    public static final int INSERT_CARD_SUCCESS = 1;
    public static final int INSERT_CARD_EXIST = 2;
    public static final int DELETE_CARD_ERROR = 0;
    public static final int DELETE_CARD_SUCCESS = 1;

    public static final int INSERT_ANALYTIC_ERROR = 0;
    public static final int INSERT_ANALYTIC_SUCCESS = 1;
    public static final int DELETE_ANALYTIC_ERROR = 0;
    public static final int DELETE_ANALYTIC_SUCCESS = 1;
    public static final int UPDATE_ANALYTIC_ERROR = 0;
    public static final int UPDATE_ANALYTIC_SUCCESS = 1;

    public static final int TYPE_VISA = 0;
    public static final int TYPE_MASTER_CARD = 1;

    public static final String DEFAULT_SUMMARY = "Summary";
    public static final String DEFAULT_ANALYTIC = "Analytic";

    public class UserDesc
    {
        public int m_iUserID;
        public String m_szUserName;
        public String m_szUserMail;
    }

    public class CardDesc
    {
        public int m_iCardID;
        public int m_iUserID;
        public int m_iType;
        public String m_szName;
        public String m_szSummary;
    }

    public static DataManager m_pstDataManager = null;
    public static UserDesc m_pstCurrentUserDesc = null;
    public static CardDesc m_pstCurrentCardDesc = null;

    public static DataManager GetDataManager()
    {
        return m_pstDataManager;
    }

    public static UserDesc GetCurrentUserDesc()
    {
        return m_pstCurrentUserDesc;
    }

    public static CardDesc GetCurrentCardDesc()
    {
        return m_pstCurrentCardDesc;
    }

    public static void ReleaseDataManager()
    {
        m_pstDataManager = null;
        m_pstCurrentUserDesc = null;
        m_pstCurrentCardDesc = null;
    }

    public DataManager(Context context)
    {
    }

    public int open()
    {
        return OPEN_ERROR;
    }

    public void close()
    {
    }

    //---- Users
    public int InsertUser(String szUserName, String szUserMail, String szPwd)
    {
        return DataManager.INSERT_USER_ERROR;
    }

    public List<UserDesc> GetUserList()
    {
        return null;
    }
    //---

    //--- Cards
    public int InsertCard(String szCardName, int iUserID, int iType, String szSummary, String szAnalytic)
    {
        return DataManager.INSERT_CARD_ERROR;
    }

    public int DeleteCard(int iCardID)
    {
        return DataManager.DELETE_CARD_ERROR;
    }

    public List<CardDesc> GetCurrentUserCardList()
    {
        return null;
    }
    //---

    //--- Analytics
    public int InsertAnalytics(int iCardID, String szDATA)
    {
        return INSERT_ANALYTIC_ERROR;
    }

    public int DeleteAnalytics(int iCardID)
    {
        return DELETE_ANALYTIC_ERROR;
    }

    public String GetAnalytics(int iCardID)
    {
        return "";
    }

    public int UpdateAnalytics(int iCardID, String szData)
    {
        return UPDATE_ANALYTIC_ERROR;
    }
    //---
}
